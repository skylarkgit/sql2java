package com.metacube.tms.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.metacube.tms.modal.GoalClassification;
public interface GoalClassificationRepository extends JpaRepository<GoalClassification, Long> {

}