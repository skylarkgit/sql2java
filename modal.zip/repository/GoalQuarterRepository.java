package com.metacube.tms.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.metacube.tms.modal.GoalQuarter;
public interface GoalQuarterRepository extends JpaRepository<GoalQuarter, Long> {

}