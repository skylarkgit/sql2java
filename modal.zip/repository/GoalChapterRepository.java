package com.metacube.tms.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.metacube.tms.modal.GoalChapter;
public interface GoalChapterRepository extends JpaRepository<GoalChapter, Long> {

}