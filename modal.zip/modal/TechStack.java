package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import javax.persistence.Enumerated;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Entity;

import java.util.List;

import javax.persistence.JoinColumn;

import java.util.UUID;

import org.hibernate.annotations.Filter;

import javax.persistence.PrePersist;

import com.metacube.tms.modal.Goal;

import javax.persistence.CascadeType;

import javax.persistence.Id;

import javax.persistence.EnumType;

import com.metacube.tms.modal.TechStackStatus;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonProperty.Access;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class TechStack extends Auditable<Long>{

private UUID uuid;


private Long orgId;


private String name;


private Long ownerId;


private Boolean isActive;


private String description;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Enumerated(EnumType.STRING)
@Type(type = "com.metacube.tms.modal.SQLEnumType")
private TechStackStatus status;

@OneToMany(cascade = {CascadeType.ALL}, orphanRemoval=true)
@JoinColumn(name="tech_stack_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<Goal> goalList;
public void setId(Long id){
this.id=id;
}

public void setUuid(UUID uuid){
this.uuid=uuid;
}

public void setOrgId(Long orgId){
this.orgId=orgId;
}

public void setName(String name){
this.name=name;
}

public void setDescription(String description){
this.description=description;
}

public void setOwnerId(Long ownerId){
this.ownerId=ownerId;
}

public void setStatus(TechStackStatus status){
this.status=status;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setGoalList(List<Goal> goalList){
this.goalList=goalList;
}
public Long getId(){
return id;
}

public UUID getUuid(){
return uuid;
}

public Long getOrgId(){
return orgId;
}

public String getName(){
return name;
}

public String getDescription(){
return description;
}

public Long getOwnerId(){
return ownerId;
}

public TechStackStatus getStatus(){
return status;
}

public Boolean getIsActive(){
return isActive;
}

public List<Goal> getGoalList(){
return goalList;
}

@PrePersist
public void prePersist(){
uuid = UUID.randomUUID();
}
}
