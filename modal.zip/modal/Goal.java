package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import com.metacube.tms.modal.GoalLevel;

import javax.persistence.GeneratedValue;

import javax.persistence.JoinTable;

import javax.persistence.Enumerated;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.metacube.tms.modal.GoalClassification;

import com.metacube.tms.modal.GoalMember;

import javax.persistence.Entity;

import java.util.List;

import com.metacube.tms.modal.GoalStatus;

import javax.persistence.ManyToOne;

import javax.persistence.JoinColumn;

import java.util.Date;

import java.util.UUID;

import org.hibernate.annotations.Filter;

import javax.persistence.ManyToMany;

import javax.persistence.PrePersist;

import com.metacube.tms.modal.Goal;

import javax.persistence.CascadeType;

import javax.persistence.Id;

import com.metacube.tms.modal.CreditPoint;

import javax.persistence.EnumType;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.metacube.tms.modal.GoalChapter;

import javax.persistence.OneToMany;

import com.metacube.tms.modal.TechStack;

import com.fasterxml.jackson.annotation.JsonProperty.Access;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Goal extends Auditable<Long>{

private UUID uuid;


private Long orgId;


private String name;


private String tags;


private String goalId;


private String version;


private Boolean isActive;


private Boolean isDeleted;


private Double courseCost;


private String courseLink;


private String description;


private Date activationDate;


private Float esimatedEffort;


private Date inactivationDate;


private String otherPrerequisite;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Enumerated(EnumType.STRING)
@Type(type = "com.metacube.tms.modal.SQLEnumType")
private GoalStatus status;

@ManyToOne
@JoinColumn(name="level_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private GoalLevel goalLevel;

@ManyToOne
@JoinColumn(name="tech_stack_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private TechStack techStack;

@ManyToOne
@JoinColumn(name="credit_point_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private CreditPoint creditPoint;

@ManyToOne
@JoinColumn(name="goal_classification_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private GoalClassification goalClassification;

@OneToMany(cascade = {CascadeType.ALL}, orphanRemoval=true)
@JoinColumn(name="goal_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<GoalMember> goalMemberList;

@OneToMany(cascade = {CascadeType.ALL}, orphanRemoval=true)
@JoinColumn(name="goal_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<GoalChapter> goalChapterList;

@ManyToMany
@JoinTable(name="goal_prerequisite", joinColumns=@JoinColumn(name="prerequisiteGoalId"), inverseJoinColumns=@JoinColumn(name="goalId"))
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<Goal> goalPrerequisiteList;
public void setId(Long id){
this.id=id;
}

public void setUuid(UUID uuid){
this.uuid=uuid;
}

public void setOrgId(Long orgId){
this.orgId=orgId;
}

public void setGoalId(String goalId){
this.goalId=goalId;
}

public void setVersion(String version){
this.version=version;
}

public void setName(String name){
this.name=name;
}

public void setDescription(String description){
this.description=description;
}

public void setStatus(GoalStatus status){
this.status=status;
}

public void setIsDeleted(Boolean isDeleted){
this.isDeleted=isDeleted;
}

public void setTags(String tags){
this.tags=tags;
}

public void setActivationDate(Date activationDate){
this.activationDate=activationDate;
}

public void setInactivationDate(Date inactivationDate){
this.inactivationDate=inactivationDate;
}

public void setOtherPrerequisite(String otherPrerequisite){
this.otherPrerequisite=otherPrerequisite;
}

public void setEsimatedEffort(Float esimatedEffort){
this.esimatedEffort=esimatedEffort;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setCourseCost(Double courseCost){
this.courseCost=courseCost;
}

public void setCourseLink(String courseLink){
this.courseLink=courseLink;
}

public void setTechStack(TechStack techStack){
this.techStack=techStack;
}

public void setGoalLevel(GoalLevel goalLevel){
this.goalLevel=goalLevel;
}

public void setCreditPoint(CreditPoint creditPoint){
this.creditPoint=creditPoint;
}

public void setGoalClassification(GoalClassification goalClassification){
this.goalClassification=goalClassification;
}

public void setGoalMemberList(List<GoalMember> goalMemberList){
this.goalMemberList=goalMemberList;
}

public void setGoalPrerequisiteList(List<Goal> goalPrerequisiteList){
this.goalPrerequisiteList=goalPrerequisiteList;
}

public void setGoalChapterList(List<GoalChapter> goalChapterList){
this.goalChapterList=goalChapterList;
}
public Long getId(){
return id;
}

public UUID getUuid(){
return uuid;
}

public Long getOrgId(){
return orgId;
}

public String getGoalId(){
return goalId;
}

public String getVersion(){
return version;
}

public String getName(){
return name;
}

public String getDescription(){
return description;
}

public GoalStatus getStatus(){
return status;
}

public Boolean getIsDeleted(){
return isDeleted;
}

public String getTags(){
return tags;
}

public Date getActivationDate(){
return activationDate;
}

public Date getInactivationDate(){
return inactivationDate;
}

public String getOtherPrerequisite(){
return otherPrerequisite;
}

public Float getEsimatedEffort(){
return esimatedEffort;
}

public Boolean getIsActive(){
return isActive;
}

public Double getCourseCost(){
return courseCost;
}

public String getCourseLink(){
return courseLink;
}

public TechStack getTechStack(){
return techStack;
}

public GoalLevel getGoalLevel(){
return goalLevel;
}

public CreditPoint getCreditPoint(){
return creditPoint;
}

public GoalClassification getGoalClassification(){
return goalClassification;
}

public List<GoalMember> getGoalMemberList(){
return goalMemberList;
}

public List<Goal> getGoalPrerequisiteList(){
return goalPrerequisiteList;
}

public List<GoalChapter> getGoalChapterList(){
return goalChapterList;
}

@PrePersist
public void prePersist(){
uuid = UUID.randomUUID();
}
}
