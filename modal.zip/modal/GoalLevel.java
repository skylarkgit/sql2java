package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.JoinColumn;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty.Access;

import org.hibernate.annotations.Filter;

import javax.persistence.CascadeType;

import javax.persistence.OneToMany;

import com.metacube.tms.modal.Goal;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;

import java.util.List;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GoalLevel extends Auditable<Long>{

private UUID uuid;


private String level;


private Boolean isActive;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@OneToMany(cascade = {CascadeType.ALL}, orphanRemoval=true)
@JoinColumn(name="level_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<Goal> goalList;
public void setId(Long id){
this.id=id;
}

public void setUuid(UUID uuid){
this.uuid=uuid;
}

public void setLevel(String level){
this.level=level;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setGoalList(List<Goal> goalList){
this.goalList=goalList;
}
public Long getId(){
return id;
}

public UUID getUuid(){
return uuid;
}

public String getLevel(){
return level;
}

public Boolean getIsActive(){
return isActive;
}

public List<Goal> getGoalList(){
return goalList;
}

@PrePersist
public void prePersist(){
uuid = UUID.randomUUID();
}
}
