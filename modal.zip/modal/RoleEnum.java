package com.metacube.tms.modal;
public enum RoleEnum {
    STACK_OWNER, ADMIN
}