package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import javax.persistence.Enumerated;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Entity;

import javax.persistence.ManyToOne;

import javax.persistence.JoinColumn;

import java.util.UUID;

import com.metacube.tms.modal.UserGoalClaim;

import org.hibernate.annotations.Filter;

import javax.persistence.OneToOne;

import javax.persistence.PrePersist;

import com.metacube.tms.modal.GoalQuarter;

import com.metacube.tms.modal.UserGoalStatusEnum;

import javax.persistence.CascadeType;

import javax.persistence.Id;

import javax.persistence.EnumType;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonProperty.Access;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class UserGoal extends Auditable<Long>{

private UUID uuid;


private Long userId;


private Long approvedBy;


private Boolean isActive;


private Boolean isDeleted;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Enumerated(EnumType.STRING)
@Type(type = "com.metacube.tms.modal.SQLEnumType")
private UserGoalStatusEnum status;

@ManyToOne
@JoinColumn(name="quarter_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private GoalQuarter goalQuarter;

@OneToOne(mappedBy="userGoal", cascade = {CascadeType.ALL}, orphanRemoval=true)
@Filter(name="activeFilter", condition="true = is_active")
private UserGoalClaim userGoalClaim;
public void setId(Long id){
this.id=id;
}

public void setUuid(UUID uuid){
this.uuid=uuid;
}

public void setUserId(Long userId){
this.userId=userId;
}

public void setStatus(UserGoalStatusEnum status){
this.status=status;
}

public void setIsDeleted(Boolean isDeleted){
this.isDeleted=isDeleted;
}

public void setApprovedBy(Long approvedBy){
this.approvedBy=approvedBy;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setGoalQuarter(GoalQuarter goalQuarter){
this.goalQuarter=goalQuarter;
}

public void setUserGoalClaim(UserGoalClaim userGoalClaim){
this.userGoalClaim=userGoalClaim;
}
public Long getId(){
return id;
}

public UUID getUuid(){
return uuid;
}

public Long getUserId(){
return userId;
}

public UserGoalStatusEnum getStatus(){
return status;
}

public Boolean getIsDeleted(){
return isDeleted;
}

public Long getApprovedBy(){
return approvedBy;
}

public Boolean getIsActive(){
return isActive;
}

public GoalQuarter getGoalQuarter(){
return goalQuarter;
}

public UserGoalClaim getUserGoalClaim(){
return userGoalClaim;
}

@PrePersist
public void prePersist(){
uuid = UUID.randomUUID();
}
}
