package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.ManyToOne;

import javax.persistence.GeneratedValue;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.JoinColumn;

import com.fasterxml.jackson.annotation.JsonProperty.Access;

import org.hibernate.annotations.Filter;

import com.metacube.tms.modal.Goal;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GoalChapter extends Auditable<Long>{

private String name;


private Float credits;


private Boolean isActive;


private String contentLink;


private String additionalLink;


private Integer chapterSequence;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@ManyToOne
@JoinColumn(name="goal_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private Goal goal;
public void setId(Long id){
this.id=id;
}

public void setName(String name){
this.name=name;
}

public void setCredits(Float credits){
this.credits=credits;
}

public void setContentLink(String contentLink){
this.contentLink=contentLink;
}

public void setChapterSequence(Integer chapterSequence){
this.chapterSequence=chapterSequence;
}

public void setAdditionalLink(String additionalLink){
this.additionalLink=additionalLink;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setGoal(Goal goal){
this.goal=goal;
}
public Long getId(){
return id;
}

public String getName(){
return name;
}

public Float getCredits(){
return credits;
}

public String getContentLink(){
return contentLink;
}

public Integer getChapterSequence(){
return chapterSequence;
}

public String getAdditionalLink(){
return additionalLink;
}

public Boolean getIsActive(){
return isActive;
}

public Goal getGoal(){
return goal;
}

@PrePersist
public void prePersist(){}
}
