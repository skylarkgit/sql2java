package com.metacube.tms.modal;
public enum TechStackStatus {
    Active, Draft, inActive
}