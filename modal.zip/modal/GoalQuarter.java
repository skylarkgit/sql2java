package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import com.metacube.tms.modal.UserGoal;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.JoinColumn;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty.Access;

import org.hibernate.annotations.Filter;

import javax.persistence.CascadeType;

import javax.persistence.OneToMany;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;

import java.util.List;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GoalQuarter extends Auditable<Long>{

private UUID uuid;


private Long year;


private String quarter;


private Boolean isActive;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@OneToMany(cascade = {CascadeType.ALL}, orphanRemoval=true)
@JoinColumn(name="quarter_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private List<UserGoal> userGoalList;
public void setId(Long id){
this.id=id;
}

public void setUuid(UUID uuid){
this.uuid=uuid;
}

public void setYear(Long year){
this.year=year;
}

public void setQuarter(String quarter){
this.quarter=quarter;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setUserGoalList(List<UserGoal> userGoalList){
this.userGoalList=userGoalList;
}
public Long getId(){
return id;
}

public UUID getUuid(){
return uuid;
}

public Long getYear(){
return year;
}

public String getQuarter(){
return quarter;
}

public Boolean getIsActive(){
return isActive;
}

public List<UserGoal> getUserGoalList(){
return userGoalList;
}

@PrePersist
public void prePersist(){
uuid = UUID.randomUUID();
}
}
