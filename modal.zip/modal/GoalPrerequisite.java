package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GoalPrerequisite extends Auditable<Long>{

private Boolean isActive;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
public void setId(Long id){
this.id=id;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}
public Long getId(){
return id;
}

public Boolean getIsActive(){
return isActive;
}

@PrePersist
public void prePersist(){}
}
