package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import javax.persistence.GeneratedValue;

import javax.persistence.EnumType;

import javax.persistence.Enumerated;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.metacube.tms.modal.RoleEnum;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class UserRole extends Auditable<Long>{

private Boolean isActive;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Enumerated(EnumType.STRING)
@Type(type = "com.metacube.tms.modal.SQLEnumType")
private RoleEnum role;
public void setId(Long id){
this.id=id;
}

public void setRole(RoleEnum role){
this.role=role;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}
public Long getId(){
return id;
}

public RoleEnum getRole(){
return role;
}

public Boolean getIsActive(){
return isActive;
}

@PrePersist
public void prePersist(){}
}
