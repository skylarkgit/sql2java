package com.metacube.tms.modal;
import javax.persistence.GenerationType;

import com.metacube.tms.modal.GoalRole;

import javax.persistence.GeneratedValue;

import javax.persistence.EnumType;

import javax.persistence.Enumerated;

import org.hibernate.annotations.Type;

import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.JoinColumn;

import com.fasterxml.jackson.annotation.JsonProperty.Access;

import org.hibernate.annotations.Filter;

import com.metacube.tms.modal.Goal;

import javax.persistence.PrePersist;

import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GoalMember extends Auditable<Long>{

private Long userId;


private Boolean isActive;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Enumerated(EnumType.STRING)
@Type(type = "com.metacube.tms.modal.SQLEnumType")
private GoalRole role;

@ManyToOne
@JoinColumn(name="goal_id")
@Filter(name="activeFilter", condition="true = is_active")
@JsonProperty(access = Access.WRITE_ONLY)
private Goal goal;
public void setId(Long id){
this.id=id;
}

public void setUserId(Long userId){
this.userId=userId;
}

public void setRole(GoalRole role){
this.role=role;
}

public void setIsActive(Boolean isActive){
this.isActive=isActive;
}

public void setGoal(Goal goal){
this.goal=goal;
}
public Long getId(){
return id;
}

public Long getUserId(){
return userId;
}

public GoalRole getRole(){
return role;
}

public Boolean getIsActive(){
return isActive;
}

public Goal getGoal(){
return goal;
}

@PrePersist
public void prePersist(){}
}
