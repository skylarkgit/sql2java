package com.metacube.tms.modal;
public enum GoalStatus {
    Ready, InReview, Draft, Active
}