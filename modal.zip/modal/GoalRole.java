package com.metacube.tms.modal;
public enum GoalRole {
    COORDINATOR, EVALUATOR
}