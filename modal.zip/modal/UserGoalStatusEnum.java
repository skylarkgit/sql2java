package com.metacube.tms.modal;
public enum UserGoalStatusEnum {
    PendingApproval, InProgress, Claimed, Approved, Rejected
}